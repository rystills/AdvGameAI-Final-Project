package muzzle;

public class Util {
}
