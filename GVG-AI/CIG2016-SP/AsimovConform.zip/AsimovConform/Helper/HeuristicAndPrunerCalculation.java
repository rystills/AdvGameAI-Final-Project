package AsimovConform.Helper;

public interface HeuristicAndPrunerCalculation {
    void doPreCalculation(AsimovState as);
}
