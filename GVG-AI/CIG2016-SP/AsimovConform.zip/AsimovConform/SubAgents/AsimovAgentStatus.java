package AsimovConform.SubAgents;

public enum AsimovAgentStatus {
    IDLE,
    RUN,
    GIVE_UP
}
