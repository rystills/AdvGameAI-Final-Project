package YOLOBOT.Util.Wissensdatenbank;

public enum PositionChange{
	none,
	top,
	right,
	bottom,
	left;
}