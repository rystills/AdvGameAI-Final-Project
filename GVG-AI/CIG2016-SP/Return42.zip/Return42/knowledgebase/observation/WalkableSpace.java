package Return42.knowledgebase.observation;

public enum WalkableSpace {
	WALKABLE,
	BLOCKED,
	MOVABLE
}
