package YOLOBOT.SubAgents.HandleMCTS.RolloutPolicies;

import java.util.ArrayList;

import YOLOBOT.BotwinState;
import ontology.Types.ACTIONS;

public abstract class RolloutPolicy {

	public ACTIONS nextAction(BotwinState state, ArrayList<ACTIONS> forbiddenActions) {
		return nextAction(state, forbiddenActions, false);
	}
	public ACTIONS nextAction(BotwinState state, ArrayList<ACTIONS> forbiddenActions, boolean forceNotEpsilon){
		ArrayList<ACTIONS> validActions = possibleNextActions(state, forbiddenActions, forceNotEpsilon);
		validActions = possibleNextActions(state, forbiddenActions, true);
		return validActions.get((int)(validActions.size()*Math.random()));
	}

	public abstract ArrayList<ACTIONS> possibleNextActions(BotwinState state, ArrayList<ACTIONS> forbiddenAction, boolean forceNotEpsilon);

}
