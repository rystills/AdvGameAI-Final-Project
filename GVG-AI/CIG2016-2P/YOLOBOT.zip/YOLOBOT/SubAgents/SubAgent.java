package YOLOBOT.SubAgents;

import java.awt.Graphics2D;

import YOLOBOT.BotwinState;
import ontology.Types;
import tools.ElapsedCpuTimer;

public abstract class SubAgent {
	public SubAgentStatus Status;
	
	public SubAgent() {
		Status = SubAgentStatus.IDLE;
	}
	
	public abstract Types.ACTIONS act(BotwinState yoloState, ElapsedCpuTimer elapsedTimer);
	
	public abstract double EvaluateWeight(BotwinState yoloState);

	public abstract void preRun(BotwinState yoloState, ElapsedCpuTimer elapsedTimer);
	
    public void draw(Graphics2D g){
    }
}
