package YOLOBOT.SubAgents;

public enum SubAgentStatus {
	IDLE,
	IN_PROGRESS,
	POSTPONED
}
