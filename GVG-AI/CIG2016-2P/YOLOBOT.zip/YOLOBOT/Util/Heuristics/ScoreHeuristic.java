package YOLOBOT.Util.Heuristics;

import YOLOBOT.BotwinState;
import YOLOBOT.Util.Wissensdatenbank.YoloKnowledge;

public class ScoreHeuristic extends IHeuristic {

	public static double max = Double.MIN_VALUE;
	
	@Override
	public double Evaluate(BotwinState ys) {
		return EvaluateWithoutNormalisation(ys)/max;

	}

	@Override
	public HeuristicType GetType() {
		return HeuristicType.ScoreHeuristic;
	}

	@Override
	public double EvaluateWithoutNormalisation(BotwinState ys) {
		if(ys != null) {
			double deltaScore = ys.getGameScore() - BotwinState.currentGameScore;
			
			if(deltaScore<0 && !YoloKnowledge.instance.isMinusScoreBad())
				deltaScore = 0;
			
			if(max < Math.abs(deltaScore)) {
				max = Math.abs(deltaScore);				
			}
			
			return deltaScore;
		}
		return 0;
	}

	@Override
	public double GetAbsoluteMax() {
		return max;
	}
}
