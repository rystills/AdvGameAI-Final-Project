package YOLOBOT.Util.Heuristics;

import YOLOBOT.BotwinState;
import tools.Vector2d;

public abstract class IModdableHeuristic extends IHeuristic{
	protected boolean targetIsToUse;
	
	public abstract double getModdedHeuristic(BotwinState state, int trueX, int trueY, Vector2d avatarOrientation);
	
	public void setTargetIsToUse(boolean value){
		targetIsToUse = value;
	}
	public boolean getZargetIsToUse(){
		return targetIsToUse;
	}

	public abstract boolean canStepOn(int myX, int myY);
}
