package YOLOBOT.Util.Wissensdatenbank;

public interface YoloEventController {
}
