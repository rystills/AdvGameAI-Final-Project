package YOLOBOT.Util;

public enum ObservationType {
	Immovable,
	Movable,
	NPC,
	Portal,
	Resource,
	FromAvatarSprite
}