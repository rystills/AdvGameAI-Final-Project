/**
 * Custom abstract player
 * 
 * @author Florian Kirchgessner (Alias: Number27)
 * @version customGA4
 */

package Number27;

import core.game.StateObservationMulti;
import ontology.Types;
import tools.ElapsedCpuTimer;

public abstract class CustomAbstractMultiPlayer {
	
    public abstract Types.ACTIONS act(StateObservationMulti stateObs, ElapsedCpuTimer elapsedTimer);

    public abstract void result(StateObservationMulti stateObservation, ElapsedCpuTimer elapsedCpuTimer);
    
    public abstract boolean switchController();
    
}
