/**
 * Using a GA for local movement and a value map to direct the player across the level. 
 * The value map is created by evaluating each object type which results in a certain influence across the map.
 * Notable events, the time spent in one area or non deterministic movements influence the players behaviour or how it chooses its optimal action.
 * 
 * Initialize and call functions of the needed controller type 
 * 
 * @author Florian Kirchgessner (Alias: Number27)
 * @version customGA3
 */

package Number27;

import core.game.StateObservationMulti;
import core.player.AbstractMultiPlayer;
import ontology.Types;
import tools.ElapsedCpuTimer;

public class Agent extends AbstractMultiPlayer {
	private CustomAbstractMultiPlayer controller;
	
    public Agent(StateObservationMulti stateObs, ElapsedCpuTimer elapsedTimer, int playerID) {
    	controller = new GA(stateObs, elapsedTimer, playerID);
    }
    

    public Types.ACTIONS act(StateObservationMulti stateObs, ElapsedCpuTimer elapsedTimer) {
    	return controller.act(stateObs, elapsedTimer);
    }
}