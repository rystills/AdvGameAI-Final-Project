package ToVo2;

import core.game.StateObservationMulti;
import core.player.AbstractMultiPlayer;
import ontology.Types;
import tools.ElapsedCpuTimer;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created with IntelliJ IDEA.
 * User: Tom Vodopivec
 * Date: 05/07/2016
 * Time: 21:45
 * This is a Java port from Tom Schaul's VGDL - https://github.com/schaul/py-vgdl
 */
public class Agent extends AbstractMultiPlayer {

    public static int[] NUM_ACTIONS;
    public static Types.ACTIONS[][] actions;
    public static int id, oppID, no_players;

    protected SingleMCTSPlayer mctsPlayer;

    /**
     * Public constructor with state observation and time due.
     * @param so state observation of the current game.
     * @param elapsedTimer Timer for the controller creation.
     */
    public Agent(StateObservationMulti so, ElapsedCpuTimer elapsedTimer, int playerID)
    {
        //get game information

        no_players = so.getNoPlayers();
        id = playerID;
        oppID = (id + 1) % so.getNoPlayers();

        //Get the actions for all players in a static array.

        NUM_ACTIONS = new int[no_players];
        actions = new Types.ACTIONS[no_players][];
        for (int i = 0; i < no_players; i++) {

            ArrayList<Types.ACTIONS> act = so.getAvailableActions(i);

            actions[i] = new Types.ACTIONS[act.size()];
            for (int j = 0; j < act.size(); ++j) {


                actions[i][j] = act.get(j);
            }
            NUM_ACTIONS[i] = actions[i].length;
        }

        //Create the player.
        mctsPlayer = getPlayer(so, elapsedTimer);

    }

    public SingleMCTSPlayer getPlayer(StateObservationMulti so, ElapsedCpuTimer elapsedTimer) {
        return new SingleMCTSPlayer(new Random());
    }


    /**
     * Picks an action. This function is called every game step to request an
     * action from the player.
     * @param stateObs Observation of the current state.
     * @param elapsedTimer Timer when the action returned is due.
     * @return An action for the current state
     */
    public Types.ACTIONS act(StateObservationMulti stateObs, ElapsedCpuTimer elapsedTimer) {

        //Set the state observation object as the new root of the tree.
        mctsPlayer.init(stateObs);

        //Determine the action using MCTS...
        int action = mctsPlayer.run(elapsedTimer);

        //... and return it.
        return actions[id][action];
    }

    public static String getConfiguration(){

        String params = "";
        params = params + "\n\t" + String.format("UCB_Cp\t%f", SingleTreeNode.UCB_Cp);
        params = params + "\n\t" + String.format("par_bestAction_visitsTolerance\t%f", SingleTreeNode.par_bestAction_visitsTolerance);
        params = params + "\n\t" + String.format("par_numMemorizedNodes\t%d", SingleTreeNode.par_numMemorizedNodes);
        params = params + "\n\t" + String.format("par_onlyFinalScoring\t%b", SingleTreeNode.par_onlyFinalScoring);
        params = params + "\n\t" + String.format("par_Qinit\t%f", SingleTreeNode.par_Qinit);
        params = params + "\n\t" + String.format("par_Qasum\t%f", SingleTreeNode.par_Qasum);
        params = params + "\n\t" + String.format("par_lambda\t%f", SingleTreeNode.par_lambda);
        params = params + "\n\t" + String.format("par_gamma\t%f", SingleTreeNode.par_gamma);
        params = params + "\n\t" + String.format("par_forgettingRate_search\t%f", SingleTreeNode.par_forgettingRate_search);
        params = params + "\n\t" + String.format("par_UCBboundMetric\t%d", SingleTreeNode.par_UCBboundMetric);
        params = params + "\n\t" + String.format("par_rollout_depth_start\t%f", SingleTreeNode.par_rollout_depth_start);
        params = params + "\n\t" + String.format("par_rollout_depth_max\t%f", SingleTreeNode.par_rollout_depth_max);
        params = params + "\n\t" + String.format("par_rollout_depth_increase_interval\t%d", SingleTreeNode.par_rollout_depth_increase_interval);
        params = params + "\n\t" + String.format("par_rollout_depth_increase_rate\t%f", SingleTreeNode.par_rollout_depth_increase_rate);
        params = params + "\n\t" + String.format("par_playoutNonUniform_start\t%f", SingleTreeNode.par_playoutNonUniform_start);
        params = params + "\n\t" + String.format("par_playoutNonUniform_max\t%f", SingleTreeNode.par_playoutNonUniform_max);
        params = params + "\n\t" + String.format("par_playoutNonUniform_increase_interval\t%d", SingleTreeNode.par_playoutNonUniform_increase_interval);
        params = params + "\n\t" + String.format("par_playoutNonUniform_increase_rate\t%f", SingleTreeNode.par_playoutNonUniform_increase_rate);
        params = params + "\n\t" + String.format("enableTightTiming\t%b", SingleTreeNode.enableTightTiming);
        params = params + "\n\t" + String.format("remainingTimeLimit\t%d", SingleTreeNode.remainingTimeLimit);
        params = params + "\n\t" + String.format("HUGE_NEGATIVE\t%f", SingleTreeNode.HUGE_NEGATIVE);
        params = params + "\n\t" + String.format("HUGE_POSITIVE\t%f", SingleTreeNode.HUGE_POSITIVE);
        params = params + "\n\t" + String.format("epsilon\t%f", SingleTreeNode.epsilon);

        return params;
    }
}
