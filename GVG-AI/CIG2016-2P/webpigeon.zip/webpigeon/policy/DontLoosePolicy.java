package webpigeon.policy;

import java.util.ArrayList;
import java.util.Random;

import core.game.StateObservationMulti;
import ontology.Types;
import ontology.Types.ACTIONS;
import tools.Utils;

/**
 * Extracted from the SampleLookAhead controller, this is their agent policy.
 */
public class DontLoosePolicy implements GVGPolicy {
	private Random m_rnd;
	private int myID;
	private int oppID;

	@Override
	public void init(int myID, int oppID) {
		this.myID = myID;
		this.oppID = oppID;
		this.m_rnd = new Random();
	}
	
	@Override
	public ACTIONS getActionAt(ACTIONS myAction, StateObservationMulti multi) {
        int no_players = multi.getNoPlayers();
        ArrayList<Types.ACTIONS> oppActions = multi.getAvailableActions(oppID);

        ArrayList<Types.ACTIONS> nonDeathActions = new ArrayList<>();

        //Look for the opp actions that would not kill the opponent.
        for (Types.ACTIONS action : multi.getAvailableActions(oppID)) {
            Types.ACTIONS[] acts = new Types.ACTIONS[no_players];
            acts[myID] = myAction;
            acts[oppID] = action;

            StateObservationMulti stCopy = multi.copy();
            stCopy.advance(acts);

            if(stCopy.getMultiGameWinner()[oppID] != Types.WINNER.PLAYER_LOSES)
                nonDeathActions.add(action);
        }

        if(nonDeathActions.isEmpty())
            //Simply random
            return oppActions.get(m_rnd.nextInt(oppActions.size()));
        else
            //Random, but among those that would not kill the opponent.
            return (Types.ACTIONS) Utils.choice(nonDeathActions.toArray(), m_rnd);
	}

}
