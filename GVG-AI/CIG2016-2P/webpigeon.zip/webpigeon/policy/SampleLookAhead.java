package webpigeon.policy;

import java.util.ArrayList;
import java.util.Random;

import controllers.multiPlayer.heuristics.SimpleStateHeuristic;
import core.game.StateObservationMulti;
import ontology.Types;
import ontology.Types.ACTIONS;
import tools.Utils;
import webpigeon.Agent;

/**
 * The sample 1 step look ahead controller ported to a policy.
 *
 * This looks like a smarter approach than mine.
 */
public class SampleLookAhead implements GVGPolicy {
    private static double epsilon = 1e-6;
	private Random m_rnd;
	private int id, oppID;
	private GVGPolicy agentModel;
	
	public SampleLookAhead() {
		this.m_rnd = new Random();
	}
	
	@Override
	public void init(int myID, int oppID) {
		this.id = myID;
		this.oppID = oppID;
		
		//this agent used it's own policy, i've made it into a GVGPolicy.
		this.agentModel = new DontLoosePolicy();
		agentModel.init(oppID, myID);
	}
	
	@Override
	public ACTIONS getActionAt(ACTIONS myAction, StateObservationMulti stateObs) {
        Types.ACTIONS bestAction = null;
        double maxQ = Double.NEGATIVE_INFINITY;

        //A random non-suicidal action by the opponent.
        Types.ACTIONS oppAction = agentModel.getActionAt(Types.ACTIONS.ACTION_NIL, stateObs);
        SimpleStateHeuristic heuristic =  new SimpleStateHeuristic(stateObs);

        for (Types.ACTIONS action : stateObs.getAvailableActions(id)) {

            StateObservationMulti stCopy = stateObs.copy();

            //need to provide actions for all players to advance the forward model
            Types.ACTIONS[] acts = new Types.ACTIONS[Agent.no_players];

            //set this agent's action
            acts[id] = action;
            acts[oppID] = oppAction;

            stCopy.advance(acts);

            double Q = heuristic.evaluateState(stCopy, id);
            Q = Utils.noise(Q, this.epsilon, this.m_rnd.nextDouble());

            //System.out.println("Action:" + action + " score:" + Q);
            if (Q > maxQ) {
                maxQ = Q;
                bestAction = action;
            }
        }

        //System.out.println("======== " + getPlayerID() + " " + maxQ + " " + bestAction + "============");
        //System.out.println(elapsedTimer.remainingTimeMillis());
        return bestAction;
	}

}
