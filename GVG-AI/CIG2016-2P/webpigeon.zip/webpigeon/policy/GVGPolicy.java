package webpigeon.policy;

import core.game.StateObservationMulti;
import core.player.AbstractMultiPlayer;
import ontology.Types;
import tools.ElapsedCpuTimer;


public interface GVGPolicy {
	
	public Types.ACTIONS getActionAt(Types.ACTIONS myAction, StateObservationMulti multi);

	public void init(int myID, int oppID);

}
