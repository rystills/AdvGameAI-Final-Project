package webpigeon.policy;

import core.game.StateObservationMulti;
import ontology.Types;
import webpigeon.Agent;


public class OneStepLookAhead implements GVGPolicy {
	
	@Override
	public Types.ACTIONS getActionAt(Types.ACTIONS myAction, StateObservationMulti multi) {
		
		Types.ACTIONS[] legalActions = Agent.actions[Agent.oppID];
		
		double bestScore = -99999;
		Types.ACTIONS bestAction = Types.ACTIONS.ACTION_NIL;
		
		Types.ACTIONS[] actionSet = new Types.ACTIONS[Agent.no_players];
		actionSet[Agent.id] = myAction;

		for (Types.ACTIONS legalAction : legalActions) {
			actionSet[Agent.oppID] = legalAction;
			
			StateObservationMulti clone = multi.copy();
			clone.advance(actionSet);
			
			if (bestScore < clone.getGameScore(Agent.oppID)) {
				bestScore = clone.getGameScore(Agent.oppID);
				bestAction = legalAction;
			}
		}
		
		return bestAction;
	}
	
	public String toString() {
		return "OneStepAhead";
	}

	@Override
	public void init(int myID, int oppID) {
		// TODO Auto-generated method stub
		
	}
	
	

}
