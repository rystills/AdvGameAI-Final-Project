package webpigeon.policy;

import core.game.StateObservationMulti;
import core.player.AbstractMultiPlayer;
import ontology.Types;


public class NestedControllerPolicy implements GVGPolicy {
	private final AbstractMultiPlayer controller;
	
	public NestedControllerPolicy(AbstractMultiPlayer controller) {
		this.controller = controller;
	}
	
	public void init(int myID, int theirID) {
		//controller.startGame(myID, theirID);
	}

	@Override
	public Types.ACTIONS getActionAt(Types.ACTIONS myAction, StateObservationMulti multi) {
		return controller.act(multi, null);
	}

	public String toString() {
		return controller.toString();
	}
	
}
