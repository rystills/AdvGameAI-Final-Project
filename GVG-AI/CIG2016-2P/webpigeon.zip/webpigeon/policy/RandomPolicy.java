package webpigeon.policy;

import java.util.Random;

import core.game.StateObservationMulti;
import ontology.Types;
import webpigeon.Agent;


public class RandomPolicy implements GVGPolicy {

	@Override
	public Types.ACTIONS getActionAt(Types.ACTIONS myAction, StateObservationMulti multi) {
		Types.ACTIONS[] oppActions = Agent.actions[Agent.oppID];
        return oppActions[new Random().nextInt(oppActions.length)];
	}

	@Override
	public void init(int myID, int oppID) {
		// TODO Auto-generated method stub
		
	}

}
