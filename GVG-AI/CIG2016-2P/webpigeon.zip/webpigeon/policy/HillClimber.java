package webpigeon.policy;

import java.util.Random;

import core.game.StateObservationMulti;
import ontology.Types;
import webpigeon.Agent;

/**
 * Return the first action strictly better than the current action.
 */
public class HillClimber implements GVGPolicy {
	private int myID;
	private int oppID;
	private Random m_rnd;
	
	@Override
	public  Types.ACTIONS getActionAt(Types.ACTIONS myAction, StateObservationMulti multi) {
		double currScore = multi.getGameScore(myID);
		
		Types.ACTIONS[] myActions = Agent.actions[myID];
		
		Types.ACTIONS[] actionSet = new Types.ACTIONS[Agent.no_players];
		actionSet[oppID] = myAction;

		for (Types.ACTIONS legalAction : myActions) {
			actionSet[myID] = legalAction;
			
			StateObservationMulti clone = multi.copy();
			clone.advance(actionSet);
			
			if (currScore < clone.getGameScore(myID)) {
				return legalAction;
			}
		}
		
		// if nothing looks better, select randomly
		return myActions[m_rnd.nextInt(myActions.length)];
	}
	
	public String toString() {
		return "HillClimb";
	}

	@Override
	public void init(int myID, int oppID) {
		this.myID = myID;
		this.oppID = oppID;
		this.m_rnd = new Random();
	}
	

}
