package CatLinux;

import core.game.StateObservationMulti;
import ontology.Types;

import java.util.Random;

/**
 * Created by jliu on 23/05/16.
 */
public class GAIndividual {
    public int genome[];
    private double fitness;

    public GAIndividual(int genome_length, int NUM_ACTIONS, Random rdm_generator) {
        this.genome = new int[genome_length];
        for(int i=0; i<genome.length;i++) {
            genome[i] = rdm_generator.nextInt(NUM_ACTIONS);
        }
        this.fitness = Double.NEGATIVE_INFINITY;
    }

    public GAIndividual(int[] _genome) {
        this.genome = new int[_genome.length];
        for(int i=0; i<genome.length;i++) {
            genome[i] = _genome[i];
        }
        this.fitness = Double.NEGATIVE_INFINITY;
    }

    public void evaluate(StateObservationMulti stateObs, Types.ACTIONS[][] actions) {
        for (int i=0; i<genome.length; i++) {
            //System.out.println("i=" + i +"; genome[i]=" + genome[i] + "; length=" + Agent.legal_actions.size());
            actions[i][Agent.id] = Agent.legal_actions.get(this.genome[i]);
            stateObs.advance(actions[i]);
            if (stateObs.isGameOver()) {
                break;
            }
        }

        this.fitness = Agent.evaluateState(stateObs);
    }

    public double getFitness() {
        return this.fitness;
    }
}
